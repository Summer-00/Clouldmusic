// pages/login04/login04.js
const app = getApp();
Page({
  checkForm:function(e){
   //1:获取参数 
   var u = e.detail.value.uname;
   var p = e.detail.value.upwd;
   //2:将用户名保存全局变量中
   app.globalData.loginName = u;
   //console.log(app.globalData.loginName);
   //3:跳转success05 组件
   //console.log(app.globalData);
   wx.navigateTo({ 
     url: '/pages/success05/success05',
   })

  },
  /**
   * 页面的初始数据
   */
  data: {
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})